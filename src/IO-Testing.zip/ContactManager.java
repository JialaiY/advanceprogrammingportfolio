import java.io.*;

public class ContactManager {
    private String[] contacts;  // Array to store contacts
    private int count;  // Keeps track of the number of contacts

    public ContactManager() {
        contacts = new String[5];  // Fixed-size array to store 5 contacts
        count = 0;
    }

    // Method to add a new contact
    public void addContact(String contact) {
        if (count < contacts.length) {
            contacts[count] = contact;
            count++;
        } else {
            System.out.println("Contact list is full!");
        }
    }

    // Method to display all contacts
    public void displayContacts() {
        for (int i = 0; i < count; i++) {
            System.out.println(contacts[i]);
        }
    }

    // Method to save contacts to a file
    public void saveToFile(String filename) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
            for (int i = 0; i < count; i++) {
                writer.write(contacts[i]);
                writer.newLine();
            }
            writer.close();
            System.out.println("Contacts saved to " + filename);
        } catch (IOException e) {
            System.out.println("Error writing to file.");
        }
    }

    // Method to load contacts from a file
    public void loadFromFile(String filename) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String line;
            count = 0;  // Reset contact count before loading
            while ((line = reader.readLine()) != null && count < contacts.length) {
                contacts[count] = line;
                count++;
            }
            reader.close();
            System.out.println("Contacts loaded from " + filename);
        } catch (IOException e) {
            System.out.println("Error reading from file.");
        }
    }
}
