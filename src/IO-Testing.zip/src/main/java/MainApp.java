import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContactManager manager = new ContactManager();  // Create a ContactManager object

        while (true) {
            System.out.println("1. Add Contact");
            System.out.println("2. Display Contacts");
            System.out.println("3. Save Contacts to File");
            System.out.println("4. Load Contacts from File");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter contact name: ");
                    String contact = scanner.nextLine();
                    manager.addContact(contact);
                    break;
                case 2:
                    manager.displayContacts();
                    break;
                case 3:
                    System.out.print("Enter filename to save: ");
                    String saveFile = scanner.nextLine();
                    manager.saveToFile(saveFile);
                    break;
                case 4:
                    System.out.print("Enter filename to load: ");
                    String loadFile = scanner.nextLine();
                    manager.loadFromFile(loadFile);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option!");
            }
        }
    }
}
