//Jialai Ying 
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<Contact> contacts = new ArrayList<>();
        // Load contacts from file
        loadContacts(contacts, "contacts.txt");

        // Main program loop
        while (true) {
            // Display menu
            System.out.println("Contact Management System");
            System.out.println("1. Add Contact");
            System.out.println("2. View Contacts");
            System.out.println("3. Delete Contact");
            System.out.println("4. Save and Exit");

            // Get user input
            System.out.print("Enter your choice: ");
            int choice = Integer.parseInt(new java.util.Scanner(System.in).nextLine());

            // Process user choice
            switch (choice) {
                case 1:
                    // Add contact
                    addContact(contacts);
                    break;
                case 2:
                    // View contacts
                    viewContacts(contacts);
                    break;
                case 3:
                    // Delete contact
                    deleteContact(contacts);
                    break;
                case 4:
                    // Save and exit
                    saveContacts(contacts, "contacts.txt");
                    System.out.println("Contacts saved successfully.");
                    System.exit(0);
                default:
                    System.out.println("That doesn't woork dummy :(.");
            }
        }
    }

    // Method to add a new contact
    private static void addContact(List<Contact> contacts) {
        System.out.print("Enter first name: ");
        String firstName = new java.util.Scanner(System.in).nextLine();
        System.out.print("Enter last name: ");
        String lastName = new java.util.Scanner(System.in).nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = new java.util.Scanner(System.in).nextLine();
        contacts.add(new Contact(firstName, lastName, phoneNumber));
        System.out.println("Contact added successfully.");
    }

    // Method to view all contacts
    private static void viewContacts(List<Contact> contacts) {
        if (contacts.isEmpty()) {
            System.out.println("No contacts found.");
            return;
        }
        System.out.println("Contacts:");
        for (Contact contact : contacts) {
            System.out.println(contact);
        }
    }

    // Method to delete a contact
    private static void deleteContact(List<Contact> contacts) {
        if (contacts.isEmpty()) {
            System.out.println("No contacts to delete.");
            return;
        }
        System.out.print("Enter the index of the contact to delete (starting from 0): ");
        int index = Integer.parseInt(new java.util.Scanner(System.in).nextLine());
        if (index < 0 || index >= contacts.size()) {
            System.out.println("Invalid index.");
            return;
        }
        contacts.remove(index);
        System.out.println("Contact deleted successfully.");
    }

    // Method to save contacts to a file
    private static void saveContacts(List<Contact> contacts, String filename) {
        try (PrintWriter writer = new PrintWriter(filename)) {
            for (Contact contact : contacts) {
                writer.println(contact.getFirstName() + "," + contact.getLastName() + "," + contact.getPhoneNumber());
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error saving contacts to file: " + e.getMessage());
        }
    }

    // Method to load contacts from a file
    private static void loadContacts(List<Contact> contacts, String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    contacts.add(new Contact(parts[0], parts[1], parts[2]));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading contacts from file: " + e.getMessage());
        }
    }
}

// Contact class
class Contact {
    private String firstName;
    private String lastName;
    private String phoneNumber;

    public Contact(String firstName, String lastName, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String toString() {
        return "Contact{" +
               "firstName='" + firstName + '\'' +
               ", lastName='" + lastName + '\'' +
               ", phoneNumber='" + phoneNumber + '\'' +
               '}';
    }
}